MJ STORE - PS4 Homebrew build starter

هذه نسخة أولية للبناء السحابي باستخدام OpenOrbis Toolchain وGitHub Actions.

ماذا تعرض النسخة الأولية؟
- تفتح واجهة التصميم الموجودة في assets/mj-store-concept.png بملء الشاشة.
- زر الرجوع (B) أو Back يغلق التطبيق.
- هذه ليست بعد مكتبة تفاعلية كاملة؛ ملفات HTML وgames.json محفوظة كمصدر للمرحلة التالية.

طريقة البناء:
1) ارفع محتويات هذا المجلد إلى جذر مستودع GitHub مع الحفاظ على المجلدات.
2) افتح Actions ثم Build MJ STORE PS4 PKG.
3) شغّل workflow يدوياً من Run workflow أو انتظر تشغيله بعد Commit.
4) عند نجاح البناء، نزّل Artifact باسم MJ-STORE-PS4-PKG.

مهم:
- ملف PKG لا يعتبر صالحاً إلا إذا اكتمل الـ workflow وظهر Artifact بعد نجاح خطوات البناء والتحقق.
- هذا مشروع Homebrew غير رسمي. لا يحتوي على ألعاب أو ملفات ألعاب.
