#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER) != 0) {
        printf("MJ STORE: SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }

    int img_flags = IMG_INIT_PNG;
    if ((IMG_Init(img_flags) & img_flags) != img_flags) {
        printf("MJ STORE: PNG init failed: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_DisplayMode mode;
    int width = 1920, height = 1080;
    if (SDL_GetCurrentDisplayMode(0, &mode) == 0) {
        width = mode.w;
        height = mode.h;
    }

    SDL_Window *window = SDL_CreateWindow("MJ STORE", SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED, width, height, SDL_WINDOW_FULLSCREEN);
    if (!window) {
        printf("MJ STORE: window failed: %s\n", SDL_GetError());
        IMG_Quit(); SDL_Quit(); return 1;
    }

    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) renderer = SDL_CreateRenderer(window, -1, 0);
    if (!renderer) {
        printf("MJ STORE: renderer failed: %s\n", SDL_GetError());
        SDL_DestroyWindow(window); IMG_Quit(); SDL_Quit(); return 1;
    }

    SDL_Surface *surface = IMG_Load("assets/mj-store-concept.png");
    if (!surface) {
        printf("MJ STORE: cannot load artwork: %s\n", IMG_GetError());
        SDL_DestroyRenderer(renderer); SDL_DestroyWindow(window);
        IMG_Quit(); SDL_Quit(); return 1;
    }
    SDL_Texture *art = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);
    if (!art) {
        printf("MJ STORE: texture failed: %s\n", SDL_GetError());
        SDL_DestroyRenderer(renderer); SDL_DestroyWindow(window);
        IMG_Quit(); SDL_Quit(); return 1;
    }

    int running = 1;
    SDL_Event event;
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) running = 0;
            if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) running = 0;
            if (event.type == SDL_CONTROLLERBUTTONDOWN &&
                (event.cbutton.button == SDL_CONTROLLER_BUTTON_B ||
                 event.cbutton.button == SDL_CONTROLLER_BUTTON_BACK)) running = 0;
        }
        SDL_SetRenderDrawColor(renderer, 3, 8, 24, 255);
        SDL_RenderClear(renderer);
        SDL_Rect dst = {0, 0, width, height};
        SDL_RenderCopy(renderer, art, NULL, &dst);
        SDL_RenderPresent(renderer);
    }

    SDL_DestroyTexture(art);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit(); SDL_Quit();
    return 0;
}
